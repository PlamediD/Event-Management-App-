/*
Name: Plamedi Diakubama
Assignment: Homework 5
Class: CPSC 4250
Date: 06/01/2023
File name: add_event.dart
Description:This is responsible for the form to register an event
I modified it to include type in the form.
The type will determine the location where the event is stored
 */
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'event.dart';
import 'event_view_model.dart';

class AddEvent extends StatefulWidget {

  @override
  _AddEventState createState() => _AddEventState();
}

class _AddEventState extends State<AddEvent> {
  String? _selectedType;
  final _formKey = GlobalKey<FormState>();
  final TextEditingController _titleController = TextEditingController();
  final TextEditingController _descriptionController = TextEditingController();
  DateTime _startDateTime = DateTime.now();
  DateTime _endDateTime = DateTime.now();

  Future<void> _selectStartDate(BuildContext context) async {
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: _startDateTime,
      firstDate: DateTime.now(),
      lastDate: DateTime(2100),
    );
    if (picked != null && picked != _startDateTime) {
      setState(() {
        _startDateTime = picked;
      });
    }
    if (_startDateTime.isAfter(_endDateTime)) {
      setState(() {
        _endDateTime = _startDateTime.add(Duration(hours: 1));
      });
    }
  }

  Future<void> _selectEndDate(BuildContext context) async {
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: _endDateTime,
      firstDate: _startDateTime,
      lastDate: DateTime(2100),
    );
    if (picked != null && picked != _endDateTime) {
      setState(() {
        _endDateTime = picked;
      });
    }
    if (_endDateTime.isBefore(_startDateTime)) {
      setState(() {
        _startDateTime = _endDateTime.subtract(Duration(hours: 1));
      });
    }
  }

  Future<void> _selectStartTime(BuildContext context) async {
    final TimeOfDay? picked = await showTimePicker(
      context: context,
      initialTime: TimeOfDay.fromDateTime(_startDateTime),
    );
    if (picked != null) {
      setState(() {
        _startDateTime = DateTime(
          _startDateTime.year,
          _startDateTime.month,
          _startDateTime.day,
          picked.hour,
          picked.minute,
        );
      });
      if (_startDateTime.isAfter(_endDateTime)) {
        setState(() {
          _endDateTime = _startDateTime.add(Duration(hours: 1));
        });
      }
    }
  }

  Future<void> _selectEndTime(BuildContext context) async {
    final TimeOfDay? picked = await showTimePicker(
      context: context,
      initialTime: TimeOfDay.fromDateTime(_endDateTime),
    );
    if (picked != null) {
      setState(() {
        _endDateTime = DateTime(
          _endDateTime.year,
          _endDateTime.month,
          _endDateTime.day,
          picked.hour,
          picked.minute,
        );
      });
      if (_endDateTime.isBefore(_startDateTime)) {
        showDialog(
          context: context,
          builder: (context) => AlertDialog(
            title: Text('Invalid Date'),
            content: Text('End date must be after start date.'),
            actions: <Widget>[
              TextButton(
                onPressed: () => Navigator.of(context).pop(),
                child: Text('OK'),
              ),
            ],
          ),
        );
      }
    }
  }

  void _saveEvent() async {
    if (_formKey.currentState!.validate()) {
      if (_descriptionController.text.isEmpty) {
        showDialog(
          context: context,
          builder: (context) => AlertDialog(
            title: Text('Invalid Description'),
            content: Text('Please enter a description for the event.'),
            actions: <Widget>[
              TextButton(
                onPressed: () => Navigator.of(context).pop(),
                child: Text('OK'),
              ),
            ],
          ),
        );
      }
      else if (_endDateTime.isBefore(_startDateTime)) {
        showDialog(
          context: context,
          builder: (context) => AlertDialog(
            title: Text('Invalid Date'),
            content: Text('End date must be after start date.'),
            actions: <Widget>[
              TextButton(
                onPressed: () => Navigator.of(context).pop(),
                child: Text('OK'),
              ),
            ],
          ),
        );
      }
      else {
        Event event = Event(
          title: _titleController.text,
          description: _descriptionController.text,
          startDateTime: _startDateTime,
          endDateTime: _endDateTime,
          type: _selectedType!,
        );

        if (_selectedType == 'private') {
          final added = await Provider.of<EventViewModel>(context, listen: false)
              .addEvent(event);

          if (added) {
            Navigator.pop(context);
          } else {
            ScaffoldMessenger.of(context).showSnackBar(SnackBar(
              content: Text('This event is a duplicate'),
            ));
          }
        } else if (_selectedType == 'shared') {
          final added = await Provider.of<EventViewModel>(context, listen: false)
              .addEventToFirestore(event);

          if (added) {
            Navigator.pop(context);
          } else {
            ScaffoldMessenger.of(context).showSnackBar(SnackBar(
              content: Text('This event is a duplicate'),
            ));

          }
        }
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Add Event'),
      ),
      body: Padding(
        padding: EdgeInsets.all(16),
        child: SingleChildScrollView(
          child: Form(
            key: _formKey,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Title(titleController: _titleController),
                SizedBox(height: 16),
                Description(descriptionController: _descriptionController),
                DropdownButtonFormField<String>(
                  value: _selectedType,
                  onChanged: (value) {
                    setState(() {
                      _selectedType = value;
                    });
                  },
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return 'Please select a type for the event';
                    }
                    return null;
                  },
                  decoration: InputDecoration(
                    labelText: 'Type',
                  ),
                  items: [
                    DropdownMenuItem(
                      value: 'private',
                      child: Text('Private'),
                    ),
                    DropdownMenuItem(
                      value: 'shared',
                      child: Text('Shared'),
                    ),
                  ],
                ),
                SizedBox(height: 16),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Expanded(
                      child: Text('Starts on: ${_startDateTime.toString()}'),
                    ),
                    ElevatedButton(
                      onPressed: () => _selectStartDate(context),
                      child: Text('Select Date'),
                    ),
                    ElevatedButton(
                      onPressed: () => _selectStartTime(context),
                      child: Text('Select Time'),
                    ),
                  ],
                ),

                SizedBox(height: 16),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Expanded(
                      child: Text('Ends on: ${_endDateTime.toString()}'),
                    ),
                    Expanded(
                      child: ElevatedButton(
                        onPressed: () => _selectEndDate(context),
                        child: Text('Select Date'),
                      ),
                    ),
                    Expanded(
                      child: ElevatedButton(
                        onPressed: () => _selectEndTime(context),
                        child: Text('Select Time'),
                      ),
                    ),
                  ],
                ),
                SizedBox(height: 16),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    ElevatedButton(
                      onPressed: _saveEvent,
                      child: Text('Save Event'),
                    ),
                    ElevatedButton(
                      onPressed: () {
                        Navigator.pop(context);
                      },
                      child: Text('Cancel'),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class Description extends StatelessWidget {
  const Description({
    super.key,
    required TextEditingController descriptionController,
  }) : _descriptionController = descriptionController;

  final TextEditingController _descriptionController;

  @override
  Widget build(BuildContext context) {
    return TextFormField(
      controller: _descriptionController,
      decoration: InputDecoration(
        labelText: 'Description',
      ),
      validator: (value) {
        if (value == null || value.isEmpty) {
          return 'Please enter a description for the event';
        }
        return null;
      },
    );
  }
}


class Title extends StatelessWidget {
  const Title({
    super.key,
    required TextEditingController titleController,
  }) : _titleController = titleController;

  final TextEditingController _titleController;

  @override
  Widget build(BuildContext context) {
    return Container(
      child: TextFormField(
        controller: _titleController,
        decoration: InputDecoration(
          labelText: 'Title',
        ),
        validator: (value) {
          if (value == null || value.isEmpty) {
            return 'Please enter a title for the event';
          }
          return null;
        },
      ),
    );
  }
}
