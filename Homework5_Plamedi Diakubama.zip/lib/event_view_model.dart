/*
Name: Plamedi Diakubama
Assignment: Homework 5
Class: CPSC 4250
Date: 06/01/2023
File name: event_view_model.dart
Description:This is the view model class that encapsulates my event data.
Keep the data structure storing the events private, and only expose methods specific
to each use case your widgets have for accessing event data.

 */

import 'package:flutter/material.dart';
import 'package:second_app/event.dart';
import 'package:second_app/event_dao.dart';
import 'package:second_app/event_database.dart';
import 'package:flutter/foundation.dart';
import 'firebase_database.dart';
import 'package:cloud_firestore/cloud_firestore.dart';


class EventViewModel extends ChangeNotifier {
  final EventDatabase _database;
  late EventDao _eventDao;
  late List<Event> _events;
  bool isLoading=true ;
  final CollectionReference<Map<String, dynamic>> _collectionReference;

  EventViewModel(this._database,  this._collectionReference) {
    _eventDao = _database.eventDao;
    _events = [];
    fetchEvents();
  }

  List<Event> get events =>_events;

  Future<void> fetchEvents() async {

    final floorEvents = await _eventDao.getEventsInChronologicalOrder();
    final firestoreEvents = await getEventsFromFirestore(_collectionReference);

    _events = [...floorEvents, ...firestoreEvents];
    if(isLoading) {
      isLoading=false;
      notifyListeners();
    }

  }

  Future<bool> addEvent(Event event) async {
    final existingEvents = _events.where(
          (e) => e.title == event.title && e.startDateTime == event.startDateTime,
    ).toList();

    if (existingEvents.isNotEmpty) {
      // Event(s) with the same title and start date/time already exist
      return false;
    }
    else {
      await _eventDao.insertEvent(event);
      _events.add(event); // Add the event to the local list
      notifyListeners();

      return true;
    }
  }

  Future<bool> addEventToFirestore(Event event) async {
    // Check if the event already exists in Firestore
    final existingEvents = _events.where(
          (e) => e.title == event.title && e.startDateTime == event.startDateTime,
    ).toList();
    if(existingEvents.isNotEmpty){
      return false;
    }
    else{
      await _collectionReference.add({
        'title': event.title,
        'description': event.description,
        'startDateTime': Timestamp.fromDate(event.startDateTime),
        'endDateTime': Timestamp.fromDate(event.endDateTime),
        'type': event.type,
      });
      events.add(event); // Add the event to the local list
      notifyListeners();
      return true;
    }

  }


  Future<void> modifyEventTime(
      Event event,
      DateTime newStartDateTime,
      DateTime newEndDateTime,
      ) async {
    final updatedEvent = event.copyWith(
      startDateTime: newStartDateTime,
      endDateTime: newEndDateTime,
    );
    await _eventDao.updateEvent(updatedEvent);

    // Update the event object in the _events list
    final index = _events.indexOf(event);
    if (index != -1) {
      _events[index] = updatedEvent;
    }

    notifyListeners();
    //fetchEvents();
  }


  Future<void> deleteEvent(Event event) async {
    await _eventDao.deleteEvent(event);
    _events.remove(event);
    //_events = await _eventDao.getEventsInChronologicalOrder();
    notifyListeners();
  }

  List<Event> getOngoingEvents() {
    final currentDate = DateTime.now();
    return _events.where((event) => event.endDateTime.isAfter(currentDate)).toList();
  }

  int getLength(){
    return _events.length;
  }

  Event getByIndex(int index){

    return _events[index];
  }


}