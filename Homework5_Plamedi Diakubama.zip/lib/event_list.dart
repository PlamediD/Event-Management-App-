/*
Name: Plamedi Diakubama
Assignment: Homework 4
Class: CPSC 4250
Date: 05/18/2023
File name: event_list.dart
Description:This is the eventList widget
It displays the event as well as the option to toggle ( show events that have not ended yet only)
Next to each event, there is the icon to modify and to delete
On the main page, it only shows the title and start date of each event. To view the remaining details,
the user needs to tap on the event of their choice
Without the comment and },) the file is less than 100 lines
User is not allowed to modify or delete shared events ( so these events do not have the icon for modify and delete)

 */
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:intl/intl.dart';
import 'package:second_app/event.dart';
import 'event_view_model.dart';
import 'delete.dart';
import 'modify.dart';
import 'package:go_router/go_router.dart';

class EventList extends StatefulWidget {
  @override
  _EventListState createState() => _EventListState();
}

class _EventListState extends State<EventList> {
  bool showAllEvents = true;

  @override
  Widget build(BuildContext context) {
    final dateFormat = DateFormat('yyyy-MM-dd hh:mm a');

    return Consumer<EventViewModel>(
      builder: (context, eventViewModel, child) {
        //eventViewModel.fetchEvents();

        final events = showAllEvents
            ? eventViewModel.events
            : eventViewModel.getOngoingEvents();
        events.sort((a, b) => a.startDateTime.compareTo(b.startDateTime));

        if (events.isEmpty) {
          eventViewModel.fetchEvents();
          if(eventViewModel.isLoading){
            return Center(
              child: Text('Loading'),
            );
          }

          //eventViewModel.fetchEvents();
          return Center(
            child: Text('No events scheduled'),
          );
        } else {
          return Column(
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  Checkbox(
                    value: showAllEvents,
                    onChanged: (value) {
                      setState(() {
                        showAllEvents = value!;
                      });
                    },
                  ),
                  Text('Show All Events'),
                ],
              ),
              Expanded(
                child: ListView.builder(
                  itemCount: events.length,
                  itemBuilder: (context, index) {
                    final event = events[index];
                    // Check if event type is 'private'
                    final bool isPrivateEvent = event.type == 'private';
                    return InkWell(
                      onTap: () {
                        final indexToGive=index;
                        context.pushNamed('detailScreen',pathParameters: {'index':index.toString()});

                      },
                      child: ListTile(
                        title: Row(
                          children: [
                            Expanded(
                              child: Title(event: event),
                            ),

                            if (isPrivateEvent) ...[
                              IconButton(
                                icon: Icon(Icons.delete),
                                onPressed: () {
                                  showDialog(
                                    context: context,
                                    builder: (context) => DeleteEventDialog(
                                      eventTitle: event.title,
                                      onConfirmDelete: () {
                                        eventViewModel.deleteEvent(event);
                                      },
                                    ),
                                  );
                                },
                              ),
                              Edit(event: event, dateFormat: dateFormat),
                            ],
                          ],
                        ),
                        subtitle: startDateTime(dateFormat: dateFormat, event: event),
                      ),
                    );
                  },
                ),
              ),
            ],
          );
        }
      },
    );
  }
}

class startDateTime extends StatelessWidget {
  const startDateTime({
    super.key,
    required this.dateFormat,
    required this.event,
  });

  final DateFormat dateFormat;
  final Event event;

  @override
  Widget build(BuildContext context) {
    return Text(
      'Start date & time ${dateFormat.format(event.startDateTime)}',
    );
  }
}

class Title extends StatelessWidget {
  const Title({
    super.key,
    required this.event,
  });

  final Event event;

  @override
  Widget build(BuildContext context) {
    return Text(
      event.title,
      style: TextStyle(
        fontWeight: FontWeight.bold,
      ),
    );
  }
}

class Edit extends StatelessWidget {
  const Edit({
    super.key,
    required this.event,
    required this.dateFormat,
  });

  final Event event;
  final DateFormat dateFormat;

  @override
  Widget build(BuildContext context) {
    return IconButton(
      icon: Icon(Icons.edit),
      onPressed: () {
        showDialog(
          context: context,
          builder: (context) => ModifyEventDialog(
            event: event,
            dateFormat: dateFormat,
          ),
        );
      },
    );
  }
}