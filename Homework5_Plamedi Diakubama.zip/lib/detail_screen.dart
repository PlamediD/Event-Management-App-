/*
Name: Plamedi Diakubama
Assignment: Homework 5
Class: CPSC 4250
Date: 06/01/2023
File name: detail_screen.dart
Description:This is responsible for displaying more detail about each event (From both databases).
The event details view should have four navigation options:
    go to the event before this one chronologically
    go to the event after this one chronologically
    go to the list of events
    go to the previous view, whatever it was
 */

import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';
import 'event_view_model.dart';
import 'package:go_router/go_router.dart';
import 'event.dart';
class EventDetails extends StatefulWidget {
  final int index;

  EventDetails({required this.index});

  @override
  _EventDetailsState createState() => _EventDetailsState();
}

class _EventDetailsState extends State<EventDetails> {
  final DateFormat dateFormat = DateFormat('yyyy-MM-dd hh:mm a');
  late EventViewModel eventViewModel;
  late Event event;
  int currentIndex = 0;

  @override
  void initState() {
    super.initState();
    eventViewModel = context.read<EventViewModel>();
    currentIndex = widget.index;
    event = eventViewModel.events[currentIndex];
  }

  void navigateToPreviousEvent() {
    if (currentIndex > 0) {
      currentIndex--;
      setState(() {
        event = eventViewModel.events[currentIndex];
      });
    }
    else{
      showDialog(
        context: context,
        builder: (context) => AlertDialog(
          title: Text('Begining of the list '),
          content: Text('There is no previous event as this is the first event.'),
          actions: <Widget>[
            TextButton(
              onPressed: () => Navigator.of(context).pop(),
              child: Text('OK'),
            ),
          ],
        ),
      );
    }
  }

  void navigateToNextEvent() {
    if (currentIndex < eventViewModel.getLength() - 1) {
      currentIndex++;
      setState(() {
        event = eventViewModel.events[currentIndex];
      });
    } else {
      showDialog(
        context: context,
        builder: (context) => AlertDialog(
          title: Text('End of List'),
          content: Text('You have reached the end of the list.'),
          actions: <Widget>[
            TextButton(
              onPressed: () => Navigator.of(context).pop(),
              child: Text('OK'),
            ),
          ],
        ),
      );
    }
  }


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(event.title),
        leading: BackButton(
          onPressed: () {
            Navigator.of(context).pop();
          },
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Description(),
            Text(event.description),
            SizedBox(height: 16),
            startDateTime(),
            Text(dateFormat.format(event.startDateTime)),
            SizedBox(height: 16),
            Text(
              'End Date & Time:',
              style: TextStyle(
                fontWeight: FontWeight.bold,
              ),
            ),
            Text(dateFormat.format(event.endDateTime)),
            SizedBox(height: 16),
            Type(),
            Text(event.type),
            SizedBox(height: 16),
          ],
        ),
      ),
      floatingActionButton: SingleChildScrollView(
        scrollDirection: Axis.horizontal,
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            ElevatedButton.icon(
              onPressed: navigateToPreviousEvent,
              icon: Icon(Icons.arrow_back),
              label: Text('Previous'),
            ),
            SizedBox(width: 8),
            ElevatedButton.icon(
              onPressed: () {
                context.pushNamed('home');
              },
              icon: Icon(Icons.list),
              label: Text('Full list'),
            ),
            SizedBox(width: 8),
            ElevatedButton.icon(
              onPressed: navigateToNextEvent,
              icon: Icon(Icons.arrow_forward),
              label: Text('Next'),
            ),
          ],
        ),
      ),
    );
  }
}

class Type extends StatelessWidget {
  const Type({
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    return Text(
      'Type:',
      style: TextStyle(
        fontWeight: FontWeight.bold,
      ),
    );
  }
}


class startDateTime extends StatelessWidget {
  const startDateTime({
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    return Text(
      'Start Date & Time:',
      style: TextStyle(
        fontWeight: FontWeight.bold,
      ),
    );
  }
}

class Description extends StatelessWidget {
  const Description({
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    return Text(
      'Description:',
      style: TextStyle(
        fontWeight: FontWeight.bold,
      ),
    );
  }
}


