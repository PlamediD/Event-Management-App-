/*
Name: Plamedi Diakubama
Assignment: Homework 5
Class: CPSC 4250
Date: 06/01/2023
File name: MockEventDao.dart
Description:This is a mock DAO that it is being used for widget testing
 */
import 'package:second_app/event.dart';
import 'package:second_app/event_dao.dart';

class MockEventDao extends EventDao {
  List<Event> events;

  MockEventDao(this.events);

  @override
  Future<List<Event>> getEventsInChronologicalOrder() async {
    return events;
  }

  @override
  Future<List<Event>> getOngoingEvents(DateTime now) async {
    return events.where((event) => event.endDateTime.isAfter(now)).toList();
  }

  @override
  Future<List<Event>> getEventsBetween(DateTime startDateTime, DateTime endDateTime) async {
    return events.where((event) =>
    event.startDateTime.isAfter(startDateTime) && event.startDateTime.isBefore(endDateTime)
    ).toList();
  }

  @override
  Future<void> insertEvent(Event event) async {
    events.add(event);
  }

  @override
  Future<void> updateEvent(Event event) async {
    final index = events.indexWhere((e) => e.id == event.id);
    if (index != -1) {
      events[index] = event;
    }
  }

  @override
  Future<void> deleteEvent(Event event) async {
    events.removeWhere((e) => e.id == event.id);
  }

  @override
  Future<Event?> getByTitleDate(String title, DateTime startDateTime) async {
    return events.firstWhere((event) =>
    event.title == title && event.startDateTime == startDateTime,
        //orElse: () => null
    );
  }
}
