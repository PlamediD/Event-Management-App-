import 'package:floor/floor.dart';
import 'event.dart';

@dao
abstract class EventDao {
  @Query('SELECT * FROM Event ORDER BY start_date_time')
  Future<List<Event>> getEventsInChronologicalOrder();

  @Query('SELECT * FROM Event WHERE end_date_time > :now')
  Future<List<Event>> getOngoingEvents(DateTime now);

  @Query('SELECT * FROM Event WHERE start_date_time BETWEEN :startDateTime AND :endDateTime')
  Future<List<Event>> getEventsBetween(DateTime startDateTime, DateTime endDateTime);

  @insert
  Future<void> insertEvent(Event event);

  @update
  Future<void> updateEvent(Event event);

  @delete
  Future<void> deleteEvent(Event event);

  @Query('SELECT * FROM Event WHERE title = :title AND start_date_time = :startDateTime')
  Future<Event?> getByTitleDate(String title, DateTime startDateTime);


}
