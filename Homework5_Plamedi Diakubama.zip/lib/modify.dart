/*
Name: Plamedi Diakubama
Assignment: Homework 5
Class: CPSC 4250
Date: 06/01/2023
File name: modify.dart
Description:This handles modifying startDateTime and/or endDateTime
 */
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:intl/intl.dart';
import 'event.dart';
import 'event_view_model.dart';

class ModifyEventDialog extends StatefulWidget {
  final Event event;
  final DateFormat dateFormat;

  ModifyEventDialog({required this.event, required this.dateFormat});

  @override
  _ModifyEventDialogState createState() => _ModifyEventDialogState();
}
class _ModifyEventDialogState extends State<ModifyEventDialog> {
  late TextEditingController _startDateController;
  late TextEditingController _endDateController;

  @override
  void initState() {
    super.initState();
    final startDateTime = widget.event.startDateTime;
    final endDateTime = widget.event.endDateTime;
    _startDateController =
        TextEditingController(text: widget.dateFormat.format(startDateTime));
    _endDateController =
        TextEditingController(text: widget.dateFormat.format(endDateTime));
  }
  @override
  void dispose() {
    _startDateController.dispose();
    _endDateController.dispose();
    super.dispose();
  }
  Future<void> _modifyEvent(EventViewModel eventViewModel) async {
    final startDate = widget.dateFormat.parse(_startDateController.text);
    final endDate = widget.dateFormat.parse(_endDateController.text);
    final newStartDateTime = DateTime(
      startDate.year,
      startDate.month,
      startDate.day,
      startDate.hour,
      startDate.minute,
    );
    final newEndDateTime = DateTime(
      endDate.year,
      endDate.month,
      endDate.day,
      endDate.hour,
      endDate.minute,
    );
    if (newEndDateTime.isAfter(newStartDateTime)) {
      await eventViewModel.modifyEventTime(
        widget.event,
        newStartDateTime,
        newEndDateTime,
      );
      Navigator.of(context).pop();
    } else {
      showDialog(
        context: context,
        builder: (context) => AlertDialog(
          title: Text('Invalid Date'),
          content: Text('End date must be after start date.'),
          actions: <Widget>[
            TextButton(
              onPressed: () => Navigator.of(context).pop(),
              child: Text('OK'),
            ),
          ],
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Consumer<EventViewModel>(
      builder: (context, eventViewModel, child) {
        return AlertDialog(
          title: Text('Modify Event'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(
                controller: _startDateController,
                decoration: InputDecoration(
                  labelText: 'Start Date',
                ),
              ),
              TextField(
                controller: _endDateController,
                decoration: InputDecoration(
                  labelText: 'End Date',
                ),
              ),
            ],
          ),
          actions: <Widget>[
            TextButton(
              onPressed: () => Navigator.of(context).pop(),
              child: Text('Cancel'),
            ),
            TextButton(
              onPressed: () => _modifyEvent(eventViewModel),
              child: Text('Save'),
            ),
          ],
        );
      },
    );
  }
}

