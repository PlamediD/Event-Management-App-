/*
Name: Plamedi Diakubama
Assignment: Homework 5
Class: CPSC 4250
Date: 02/01/2023
File name: event.dart


 */

import 'package:floor/floor.dart';
import 'package:flutter/foundation.dart';

@entity
class Event {
  @PrimaryKey(autoGenerate: true)
  final int? id;

  final String title;
  final String description;
  final String type;

  @ColumnInfo(name: 'start_date_time')
  final DateTime startDateTime;

  @ColumnInfo(name: 'end_date_time')
  final DateTime endDateTime;

  Event({
    this.id,
    required this.title,
    required this.description,
    required this.type,
    required this.startDateTime,
    required this.endDateTime,

  });

  Event copyWith({
    int? id,
    String? title,
    String? description,
    String? type,
    DateTime? startDateTime,
    DateTime? endDateTime,
  }) {
    return Event(
      id: id ?? this.id,
      title: title ?? this.title,
      description: description ?? this.description,
      type:type?? this.type,

      startDateTime: startDateTime ?? this.startDateTime,
      endDateTime: endDateTime ?? this.endDateTime,
    );
  }
}

