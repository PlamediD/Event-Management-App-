// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'event_database.dart';

// **************************************************************************
// FloorGenerator
// **************************************************************************

// ignore: avoid_classes_with_only_static_members
class $FloorEventDatabase {
  /// Creates a database builder for a persistent database.
  /// Once a database is built, you should keep a reference to it and re-use it.
  static _$EventDatabaseBuilder databaseBuilder(String name) =>
      _$EventDatabaseBuilder(name);

  /// Creates a database builder for an in memory database.
  /// Information stored in an in memory database disappears when the process is killed.
  /// Once a database is built, you should keep a reference to it and re-use it.
  static _$EventDatabaseBuilder inMemoryDatabaseBuilder() =>
      _$EventDatabaseBuilder(null);
}

class _$EventDatabaseBuilder {
  _$EventDatabaseBuilder(this.name);

  final String? name;

  final List<Migration> _migrations = [];

  Callback? _callback;

  /// Adds migrations to the builder.
  _$EventDatabaseBuilder addMigrations(List<Migration> migrations) {
    _migrations.addAll(migrations);
    return this;
  }

  /// Adds a database [Callback] to the builder.
  _$EventDatabaseBuilder addCallback(Callback callback) {
    _callback = callback;
    return this;
  }

  /// Creates the database and initializes it.
  Future<EventDatabase> build() async {
    final path = name != null
        ? await sqfliteDatabaseFactory.getDatabasePath(name!)
        : ':memory:';
    final database = _$EventDatabase();
    database.database = await database.open(
      path,
      _migrations,
      _callback,
    );
    return database;
  }
}

class _$EventDatabase extends EventDatabase {
  _$EventDatabase([StreamController<String>? listener]) {
    changeListener = listener ?? StreamController<String>.broadcast();
  }

  EventDao? _eventDaoInstance;

  Future<sqflite.Database> open(
    String path,
    List<Migration> migrations, [
    Callback? callback,
  ]) async {
    final databaseOptions = sqflite.OpenDatabaseOptions(
      version: 1,
      onConfigure: (database) async {
        await database.execute('PRAGMA foreign_keys = ON');
        await callback?.onConfigure?.call(database);
      },
      onOpen: (database) async {
        await callback?.onOpen?.call(database);
      },
      onUpgrade: (database, startVersion, endVersion) async {
        await MigrationAdapter.runMigrations(
            database, startVersion, endVersion, migrations);

        await callback?.onUpgrade?.call(database, startVersion, endVersion);
      },
      onCreate: (database, version) async {
        await database.execute(
            'CREATE TABLE IF NOT EXISTS `Event` (`id` INTEGER PRIMARY KEY AUTOINCREMENT, `title` TEXT NOT NULL, `description` TEXT NOT NULL, `type` TEXT NOT NULL, `start_date_time` INTEGER NOT NULL, `end_date_time` INTEGER NOT NULL)');

        await callback?.onCreate?.call(database, version);
      },
    );
    return sqfliteDatabaseFactory.openDatabase(path, options: databaseOptions);
  }

  @override
  EventDao get eventDao {
    return _eventDaoInstance ??= _$EventDao(database, changeListener);
  }
}

class _$EventDao extends EventDao {
  _$EventDao(
    this.database,
    this.changeListener,
  )   : _queryAdapter = QueryAdapter(database),
        _eventInsertionAdapter = InsertionAdapter(
            database,
            'Event',
            (Event item) => <String, Object?>{
                  'id': item.id,
                  'title': item.title,
                  'description': item.description,
                  'type': item.type,
                  'start_date_time':
                      _dateTimeConverter.encode(item.startDateTime),
                  'end_date_time': _dateTimeConverter.encode(item.endDateTime)
                }),
        _eventUpdateAdapter = UpdateAdapter(
            database,
            'Event',
            ['id'],
            (Event item) => <String, Object?>{
                  'id': item.id,
                  'title': item.title,
                  'description': item.description,
                  'type': item.type,
                  'start_date_time':
                      _dateTimeConverter.encode(item.startDateTime),
                  'end_date_time': _dateTimeConverter.encode(item.endDateTime)
                }),
        _eventDeletionAdapter = DeletionAdapter(
            database,
            'Event',
            ['id'],
            (Event item) => <String, Object?>{
                  'id': item.id,
                  'title': item.title,
                  'description': item.description,
                  'type': item.type,
                  'start_date_time':
                      _dateTimeConverter.encode(item.startDateTime),
                  'end_date_time': _dateTimeConverter.encode(item.endDateTime)
                });

  final sqflite.DatabaseExecutor database;

  final StreamController<String> changeListener;

  final QueryAdapter _queryAdapter;

  final InsertionAdapter<Event> _eventInsertionAdapter;

  final UpdateAdapter<Event> _eventUpdateAdapter;

  final DeletionAdapter<Event> _eventDeletionAdapter;

  @override
  Future<List<Event>> getEventsInChronologicalOrder() async {
    return _queryAdapter.queryList(
        'SELECT * FROM Event ORDER BY start_date_time',
        mapper: (Map<String, Object?> row) => Event(
            id: row['id'] as int?,
            title: row['title'] as String,
            description: row['description'] as String,
            type: row['type'] as String,
            startDateTime:
                _dateTimeConverter.decode(row['start_date_time'] as int),
            endDateTime:
                _dateTimeConverter.decode(row['end_date_time'] as int)));
  }

  @override
  Future<List<Event>> getOngoingEvents(DateTime now) async {
    return _queryAdapter.queryList(
        'SELECT * FROM Event WHERE end_date_time > ?1',
        mapper: (Map<String, Object?> row) => Event(
            id: row['id'] as int?,
            title: row['title'] as String,
            description: row['description'] as String,
            type: row['type'] as String,
            startDateTime:
                _dateTimeConverter.decode(row['start_date_time'] as int),
            endDateTime:
                _dateTimeConverter.decode(row['end_date_time'] as int)),
        arguments: [_dateTimeConverter.encode(now)]);
  }

  @override
  Future<List<Event>> getEventsBetween(
    DateTime startDateTime,
    DateTime endDateTime,
  ) async {
    return _queryAdapter.queryList(
        'SELECT * FROM Event WHERE start_date_time BETWEEN ?1 AND ?2',
        mapper: (Map<String, Object?> row) => Event(
            id: row['id'] as int?,
            title: row['title'] as String,
            description: row['description'] as String,
            type: row['type'] as String,
            startDateTime:
                _dateTimeConverter.decode(row['start_date_time'] as int),
            endDateTime:
                _dateTimeConverter.decode(row['end_date_time'] as int)),
        arguments: [
          _dateTimeConverter.encode(startDateTime),
          _dateTimeConverter.encode(endDateTime)
        ]);
  }

  @override
  Future<Event?> getByTitleDate(
    String title,
    DateTime startDateTime,
  ) async {
    return _queryAdapter.query(
        'SELECT * FROM Event WHERE title = ?1 AND start_date_time = ?2',
        mapper: (Map<String, Object?> row) => Event(
            id: row['id'] as int?,
            title: row['title'] as String,
            description: row['description'] as String,
            type: row['type'] as String,
            startDateTime:
                _dateTimeConverter.decode(row['start_date_time'] as int),
            endDateTime:
                _dateTimeConverter.decode(row['end_date_time'] as int)),
        arguments: [title, _dateTimeConverter.encode(startDateTime)]);
  }

  @override
  Future<void> insertEvent(Event event) async {
    await _eventInsertionAdapter.insert(event, OnConflictStrategy.abort);
  }

  @override
  Future<void> updateEvent(Event event) async {
    await _eventUpdateAdapter.update(event, OnConflictStrategy.abort);
  }

  @override
  Future<void> deleteEvent(Event event) async {
    await _eventDeletionAdapter.delete(event);
  }
}

// ignore_for_file: unused_element
final _dateTimeConverter = DateTimeConverter();
