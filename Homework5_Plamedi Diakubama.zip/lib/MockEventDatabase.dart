/*
Name: Plamedi Diakubama
Assignment: Homework 4
Class: CPSC 4250
Date: 05/18/2023
File name: MockEventDatabase.dart
Description:This is a mock database that it is being used for widget testing
 */

import 'package:second_app/event.dart';
import 'package:second_app/event_database.dart';
import 'package:second_app/event_dao.dart';
import 'package:second_app/MockEventDao.dart';

class MockEventDatabase extends EventDatabase {
  MockEventDao _eventDao = MockEventDao();

  @override
  EventDao get eventDao => _eventDao;
}

class MockEventDao extends EventDao {
  List<Event> _events = [];

  @override
  Future<List<Event>> getEventsInChronologicalOrder() async {
    return _events;
  }

  @override
  Future<List<Event>> getOngoingEvents(DateTime now) async {
    return _events.where((event) => event.endDateTime.isAfter(now)).toList();
  }

  @override
  Future<List<Event>> getEventsBetween(DateTime startDateTime, DateTime endDateTime) async {
    return _events.where((event) =>
    event.startDateTime.isAfter(startDateTime) && event.startDateTime.isBefore(endDateTime)
    ).toList();
  }

  @override
  Future<void> insertEvent(Event event) async {
    _events.add(event);
  }

  @override
  Future<void> updateEvent(Event event) async {
    final index = _events.indexWhere((e) => e.id == event.id);
    if (index != -1) {
      _events[index] = event;
    }
  }

  @override
  Future<void> deleteEvent(Event event) async {
    _events.removeWhere((e) => e.id == event.id);
  }

  @override
  Future<Event?> getByTitleDate(String title, DateTime startDateTime) async {
    return _events.firstWhere((event) =>
    event.title == title && event.startDateTime == startDateTime,
        //orElse: () => null
    );
  }
}