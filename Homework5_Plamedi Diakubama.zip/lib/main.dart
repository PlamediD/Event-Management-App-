/*
Name: Plamedi Diakubama
Assignment: Homework 5
Class: CPSC 4250
Date: 06/01/2023
File name: main.dart
Description:This is the main file for the app
It initializes the floor database as well as firestore collection  and define the different router
It calls the eventList widget to display events and
at the bottom right there is a + icon to allow the user to register new events

I would like to have HW2 regraded.
I fixed the following issues:
  1. duplicated events (I consider two events to be duplicated if they have the same title and start date.
I think title alone is not very efficient since events can be recurring. )
  2. Event with past startDateTime. When creating an event now, the user can no longer select a date in the past
  3. Random values appear for Time in all the events. For each event, it is displaying the correct time now

 */
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:second_app/event_view_model.dart';
import 'event_database.dart';
import 'package:go_router/go_router.dart';
import 'package:intl/intl.dart';
import 'event_list.dart';
import 'detail_screen.dart';
import 'add_event.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:cloud_firestore/cloud_firestore.dart';


final dateFormat = DateFormat('yyyy-MM-dd hh:mm a');
GoRouter router = GoRouter(
  initialLocation:'/home',
  // define your routes
  routes: [
  GoRoute(
  path: '/home',
  name: 'home',
  builder: (context, state) => EventListScreen(),
),
    GoRoute(
      path: '/add_event',
      name: 'add_event',
      builder: (context, state) => AddEvent(),
    ),

    GoRoute(
      path: "/detailScreen/:index",
      name: 'detailScreen',
      builder: (context, state) => EventDetails(index: int.parse(state.pathParameters['index']!)),

    ),
  ],
);
void main() async {

  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();

  final collectionReference = FirebaseFirestore.instance.collection('events');

  WidgetsFlutterBinding.ensureInitialized();

  // Initialize the database
  final database = await $FloorEventDatabase.databaseBuilder('new event_database.db').build();



  runApp(MyApp(database: database, collectionReference: collectionReference));
}

class MyApp extends StatelessWidget {
  final EventDatabase database;
  final CollectionReference< Map< String, dynamic>>collectionReference;

  const MyApp({required this.database, required this.collectionReference});

  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider<EventViewModel>(
      create: (context) => EventViewModel(database,collectionReference ),
      child: MaterialApp.router(
        title: 'Event Management App',
        routerConfig: router,
        debugShowCheckedModeBanner: false,
        theme: ThemeData(
          primarySwatch: Colors.green,
        ),

      ),

    );

  }

}


class EventListScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Event List'),
      ),
      body: EventList(),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          context.pushNamed("add_event");
        },
        child: Icon(Icons.add),
      ),
    );
  }
}
