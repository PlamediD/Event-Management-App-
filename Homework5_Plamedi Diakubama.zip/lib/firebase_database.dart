/*
Name: Plamedi Diakubama
Assignment: Homework 5
Class: CPSC 4250
Date: 06/01/2023
File name: firebase_database.dart
This retrieves all the events from firestore

 */

import 'package:cloud_firestore/cloud_firestore.dart';
import 'event.dart';

Future<List<Event>> getEventsFromFirestore(CollectionReference<Map<String, dynamic>> collectionReference) async {


  final querySnapshot = await collectionReference.get();

  final events = querySnapshot.docs.map((doc) {
    final data = doc.data();

    return Event(

      title: data['title'],
      description: data['description'],
      type: data['type'],
      startDateTime: (data['startDateTime'] as Timestamp).toDate(),
      endDateTime: (data['endDateTime'] as Timestamp).toDate(),
    );
  }).toList();
  return events;
}

