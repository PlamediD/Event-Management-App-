import 'package:flutter/material.dart';


class DeleteEventDialog extends StatelessWidget {
  final String eventTitle;
  final Function onConfirmDelete;

  DeleteEventDialog({required this.eventTitle, required this.onConfirmDelete});

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: Text('Confirm Delete'),
      content: Text('Are you sure you want to delete $eventTitle?'),
      actions: <Widget>[
        TextButton(
          onPressed: () => Navigator.of(context).pop(false),
          child: Text('No'),
        ),
        TextButton(
          onPressed: () {
            onConfirmDelete();
            Navigator.of(context).pop(true);
          },
          child: Text('Yes'),
        ),
      ],
    );
  }
}
